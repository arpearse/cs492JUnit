public class Calculate {
    
    public int add (int n1, int n2){
        return n1 + n2;
    }
    
    public int subtract (int n1, int n2){
        return n1 - n2;
    }
    
    public int multiply (int n1, int n2){
        return n1 * n2;
    }
    
    public Integer divide (int n1, int n2){
        if (n2 == 0)
            return null;
        
        return n1 / n2;
    }
    
}
