import org.junit.Test;
import static org.junit.Assert.*;


public class CalculateTest {
    private Calculate calc;
    
    
    public CalculateTest(){
        calc = new Calculate();
    }
    
    @Test
    public void testAdd() {
        int expected = 5;
        int actual = calc.add(2, 3);
        
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSubtract() {
        int expected = 6;
        int actual = calc.subtract(12, 6);
        
        assertEquals(expected, actual);
    }
    
    @Test
    public void testMultiply() {
        int expected = 15;
        int actual = calc.multiply(5, 3);
        
        assertEquals(expected, actual);
    }
    
    @Test
    public void testDivide() {
        Integer expected = calc.divide(1, 0);
        
        assertNull(expected);
    }

    
}
