import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
    CalculateTest.class,
    FactorialTest.class,
    ParameterizedTest.class
})

public class AllTest {
}
