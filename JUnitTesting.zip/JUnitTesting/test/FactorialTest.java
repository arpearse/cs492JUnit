import org.junit.Test;
//import static org.junit.Assert.*;

public class FactorialTest {

    @Test (expected=IllegalArgumentException.class)
    public void testFactorial() {
        Factorial f = new Factorial();
        f.factorial(-3);
    }
    
}
