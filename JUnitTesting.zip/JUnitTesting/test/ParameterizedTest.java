import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Collection;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTest {
    private int fact;
    private int total;

    
    public ParameterizedTest(int fact, int total) {
        this.fact = fact;
        this.total = total;
    }
    
    @Parameters
    public static Collection<Object[]> data() {
        Object[][] data = new Object[][] { { 3, 6 } , { 2, 2 },
                                           { 5, 120 }, { 4, 24 } };
        return Arrays.asList(data);
    }

    @Test
    public void testFactorial() {
        Factorial f = new Factorial();
        assertTrue( f.factorial(fact) == total );
    }
    
}
